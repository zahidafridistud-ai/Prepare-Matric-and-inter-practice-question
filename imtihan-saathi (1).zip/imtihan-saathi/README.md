# 📚 Imtihan Saathi

Exam practice for Pakistani **Matric and Inter** students, built from their **own textbook chapters**.

Upload or paste a chapter and the app will:

1. Create board-style practice questions (MCQs, short, long)
2. Check each answer **against the chapter only**
3. Explain mistakes in **English, Urdu (اردو) or Roman Urdu**

Built with Streamlit and Google Gemini. The API key stays in Streamlit secrets, so students never see it.

## Files

```
imtihan-saathi/
├── app.py                          # the whole app
├── requirements.txt                # Python packages
├── .gitignore
├── README.md
└── .streamlit/
    └── secrets.toml.example        # template for your key
```

## Deploy on Streamlit Community Cloud (free)

1. Push these files to a GitHub repository (do **not** upload a real `secrets.toml`).
2. Go to <https://share.streamlit.io> and sign in with GitHub.
3. Click **Create app**, choose your repository, branch `main`, and main file path `app.py`.
4. Open **Advanced settings → Secrets** and paste:
   ```toml
   GEMINI_API_KEY = "your_real_key_here"
   GEMINI_MODEL = "gemini-2.5-flash"
   ```
5. Click **Deploy**. Share the link with students.

To change the key later: **Manage app → Settings → Secrets**.

Get a free key at <https://aistudio.google.com/apikey>.

## Run on your computer

```bash
pip install -r requirements.txt
mkdir -p .streamlit
cp .streamlit/secrets.toml.example .streamlit/secrets.toml   # then edit it and add your key
streamlit run app.py
```

Open <http://localhost:8501>.

## Settings

| Secret | Default | Meaning |
|---|---|---|
| `GEMINI_API_KEY` | none | Your Gemini key (required) |
| `GEMINI_MODEL` | `gemini-2.5-flash` | Change if Google updates model names |
| `MAX_CALLS_PER_SESSION` | `60` | Max AI requests per visitor session |

## Security notes

- Never commit `secrets.toml` or paste your key into code. If a key leaks, delete it in Google AI Studio and make a new one.
- The per-session limit is simple. For a big public launch, add a login so your free Gemini quota is not used up.
- Textbook text is sent to Google Gemini for processing. Only upload material you are allowed to use.

## License

MIT. Use it freely for education.
